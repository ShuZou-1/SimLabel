import torch
from torch.utils.data import DataLoader
import clip
import json
from torch.nn import functional as F
from torchvision.datasets import ImageFolder
from tqdm.auto import tqdm, trange
import models
import utils
from datasets import _transform, CUBDataset
import numpy as np
import os

def wordify(string):
    word = string.replace('_', ' ')
    return word

def estimating_compactness(dataloader, max_epochs=50):
    vmf = models.vMF(x_dim=512)
    # vmf.set_params(mu=torch.mean(image_init,dim=0), kappa=torch.tensor(0))
    vmf = vmf.cuda()

    params = list(vmf.parameters())
    optim = torch.optim.Adam(params, lr=1e-2, betas=[0.9, 0.99],weight_decay=0.005)
    lr_sched = torch.optim.lr_scheduler.ExponentialLR(optimizer=optim, gamma=0.95)

    # SGD training
    for epoch in trange(max_epochs):
        obj, nsamps = 0.0, 0
        
        for _, images_in in enumerate(dataloader):
            # print(images_in)
            data = images_in.cuda()
            # print(-vmf(data).shape)
            enll = -vmf(data).mean()
            optim.zero_grad()
            enll.backward()
            optim.step()
            obj += enll.item()*data.shape[0]
            nsamps += data.shape[0]
            # break
            
        obj /= nsamps

        lr_sched.step()

        if (epoch+1) % 10 == 0:
            with torch.no_grad():
                mu, kappa = vmf.get_params()
            prn_str = '== After epoch %d ==\n' % epoch
            prn_str += 'Expectected negative log-likelihood = %.4f\n' % enll.item()
            # print(prn_str)

    return vmf

if __name__ == "__main__":
    clip_model,preprocess =clip.load('ViT-B/16',device='cuda',jit=False)
    batch_size = 10
    max_epochs = 20
    
    num_workers = 0
    
    def load_json(filename):
        if not filename.endswith('.json'):
            filename += '.json'
        with open(filename, 'r') as fp:
            return json.load(fp)
    
    
    # I will firstly try the ImageNet and load into the dataloader
    
    IMAGENET_DIR  = '/data/qinyu/ImageNet_1k_2012/val'
    IMAGENET_LABEL_DIR = './data/descriptors_imagenet.json'
    
    tfms = _transform(224)
    imageNet_dataset      = ImageFolder(IMAGENET_DIR, transform=tfms)
    imageNet_dataloader = DataLoader(imageNet_dataset, batch_size=batch_size, shuffle=False, num_workers = num_workers, pin_memory=True)
    
    imageNet_label        = load_json(IMAGENET_LABEL_DIR).keys()
    
    # this is the step in estimating the compactness k for the whole dataset
    # vmf_dataset = estimating_Compactness(clip_model,imageNet_dataloader)
    
    with open('./data/classwise_max_sim_true.json') as json_file:
        dis_imageNet = json.load(json_file)
    
    num_in = 0 
    sorted_dict = dict(sorted(dis_imageNet.items(), key = lambda d:len(d[1]),reverse=True)[:9]).keys()
    print(list(sorted_dict))
    
    
    print("now we get top 9 classes where most of the images will be assigned into due to the similarity score")
    
    
    # top 9 classes where there are a lot of embedding
    
    # finding the corresponding images belong to the label
    text_tokens = clip.tokenize(["" + wordify(l) + '' for l in imageNet_label]).cuda()
    text_embedding   = F.normalize(clip_model.encode_text(text_tokens))
    
    for label in list(sorted_dict):
        # for each label, find the image embeddin with the highest similarity in that label
        embed_label = None
    
        # search for whether it exist
        label_path = list(imageNet_label)[int(label)]
        label_path = label_path.replace("/", "_").replace(" ", "_")
        
        DIR = "class_wise_embedding/imageNet/"+ label_path+".npy"
        if (os.path.isfile(DIR)):
            embed_label = np.load(DIR)
        
        else:
            # calculating the images for the label 
            # print(int(label))
            print("recoding the iamges for class " + label_path)
    
            for _, (images_in,_) in enumerate(tqdm(imageNet_dataloader)):
                image_emb  = clip_model.encode_image(images_in.cuda())
                sim_cal    = image_emb@ text_embedding.T
                prediction = sim_cal.argmax(dim=1).tolist()
    
                # indices = [i for i, x in enumerate(prediction) if x == int(label)]
                indices = [i for i, x in enumerate(prediction) if str(x) in sorted_dict]
    
                selected = [image_emb[i].detach().cpu().numpy()  for i in indices]
    
                if (embed_label==None):
                    if(len(selected)>0):
                        embed_label = selected
                else:
                    if(len(selected)>0):
                        embed_label = embed_label + selected
                        
            embed_label = np.array(embed_label)
            np.save(DIR, embed_label)
    # now 

        # now obtain the compacteness
        class_dataloader = DataLoader(torch.from_numpy(embed_label), batch_size=len(embed_label)//4, shuffle=True)
        print("now, we start training for a vmf distirbution of class "+list(imageNet_label)[int(label)])
        
        vmf_class = estimating_Compactness(class_dataloader,max_epochs = 2 )
        print("the compactness k for class "+list(imageNet_label)[int(label)]+" is "+str(vmf_class.get_params()[1]))
        